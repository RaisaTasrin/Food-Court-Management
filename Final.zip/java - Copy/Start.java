import code.*;
public class Start 
{
	public static void main(String [] args)
	{
		UserLogin f = new UserLogin();
		f.setVisible(true);
	}
}