package code;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class Bkash extends JFrame implements ActionListener
{
	JPanel p;
	JLabel l1,l2,l3,l, ImageL;
	JTextField t1;
	JPasswordField t2;
	JButton b1,b2,b3;

	
	Bkash()
	{
		super(" Bkash ");	
		this.setSize(1188,850);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon icon = new ImageIcon("AppIcon.jpg");
        this.setIconImage(icon.getImage());
		
		p = new JPanel();
		p.setSize(new Dimension(1188,850));
		p.setBackground(Color.gray);
		p.setLayout(null);

		ImageIcon img = new ImageIcon("Payment.jpg");

	    ImageL = new JLabel(img);
		ImageL.setBounds(600,0,575,850);
		ImageL.setBackground(Color.white);
		p.add(ImageL);
		
		l1 = new JLabel(" Bkash ");
		l1.setFont(new Font("Candara",Font.BOLD,40));
		l1.setForeground(Color.BLACK);
		l1.setBounds(250,50,450,50);
		p.add(l1);
		
		l2 = new JLabel(" Bkash Number : ");
		l2.setFont(new Font("Candara",Font.BOLD,25));
		l2.setForeground(Color.black);
		l2.setBounds(220,220,350,30);
		p.add(l2); 
		
		l3 = new JLabel(" Password         : ");
		l3.setFont(new Font("Candara",Font.BOLD,25));
		l3.setForeground(Color.black);
		l3.setBounds(220,280,350,30);
		p.add(l3); 
		
		t1 = new JTextField();
		t1.setBounds(410,220,180,30);
		p.add(t1);
		
		t2 = new JPasswordField();
        t2.setBounds(410,280,180,30);
        p.add(t2);	
		
		
		b2 = new JButton("Next");
		b2.setBounds(450,700,120,30);
		b2.addActionListener(this);
		p.add(b2);
		
		b3 = new JButton("Back");
		b3.setBounds(50,700,120,30);
		b3.addActionListener(this);
		p.add(b3);
		
		this.add(p);
		
	}
	


public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b2)
			{
				
				String fullName = t1.getText();
                String userPassword = t2.getText();

            if(fullName.isEmpty() ||  userPassword.isEmpty())
            {
                JOptionPane.showMessageDialog(null, "Full Fill All Box");
            }
            else
            {
                JOptionPane.showMessageDialog(null,"Payment Successful");
                t1.setText("");
                t2.setText("");
				
				ThankYou f = new ThankYou();
				this.setVisible(false);
				f.setVisible(true);

            }
			}

		else if(ae.getSource()==b3)
			{
				Payment f = new Payment();
				this.setVisible(false);
				f.setVisible(true);
			}
	}


}
