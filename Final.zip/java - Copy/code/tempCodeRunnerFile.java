// Profile..................
		// prfP1 = new JPanel();
		// prfP1.setBounds(15,15,100,75);
		// prfP1.setLayout(null);
		// profile.add(prfP1);

		// prfL1 = new JLabel();
		// prfL1.setLayout(null);
		// prfL1.setBounds(0,0,100,75);
		// prfL1.setIcon(new ImageIcon(pPic));
		// prfP1.add(prfL1);

		// userNameTF = new JTextField();
		// userNameTF.setBounds(15, 100, 100, 30);
		// userNameTF.setText("Alvi");
		// userNameTF.setEditable(false);
		// profile.add(userNameTF);

		// profileB = new JButton("Profile");
		// profileB.setBounds(15, 160, 100, 30);
		// profileB.setFont(font16);
		// profile.add(profileB);