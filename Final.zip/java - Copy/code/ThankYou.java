package code;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class ThankYou extends JFrame{
	JPanel p;
	JLabel l1,l;
	
	
	ThankYou()
	{
		super(" End ");	
		this.setSize(800,600);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon icon = new ImageIcon("AppIcon.jpg");
        this.setIconImage(icon.getImage());
		
		p = new JPanel();
		p.setSize(new Dimension(450,300));
		p.setBackground(Color.gray);
		p.setLayout(null);
		
	
		
		l1 = new JLabel(" Thank You ");
		l1.setFont(new Font("Serif",Font.BOLD,50));
		l1.setForeground(Color.BLACK);
		l1.setBounds(250,50,650,100);
	    p.add(l1);
		
		this.add(p);
		
    }
	
}