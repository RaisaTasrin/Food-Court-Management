package code;
import javax.swing.*;

import java.awt.*;
import java.awt.event.*;

public class Payment extends JFrame implements ActionListener
{
	JPanel p;
	JLabel l1,l2,l, ImageL;
	JRadioButton l3,l4,l5;
	ButtonGroup g;
	JButton b1,b2;


	
	Payment()
	{
		super(" Payment method ");	
		this.setSize(1188,850);
		this.setLocationRelativeTo(null);
		this.setResizable(false);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ImageIcon icon = new ImageIcon("AppIcon.jpg");
        this.setIconImage(icon.getImage());
		
		p = new JPanel();
		p.setBounds(0, 0, 1188, 850);;
		p.setBackground(Color.gray);
		p.setLayout(null);
		
		ImageIcon img = new ImageIcon("Payment.jpg");

	    ImageL = new JLabel(img);
		ImageL.setBounds(600,0,575,850);
		ImageL.setBackground(Color.white);
		p.add(ImageL);
	
		
		l1 = new JLabel(" Payment method ");
		l1.setFont(new Font("Candara",Font.BOLD,40));
		l1.setForeground(Color.BLACK);
		l1.setBounds(250,50,450,50);
		p.add(l1);
		
	
		
		l3 = new JRadioButton(" Nagad ");
		l3.setFont(new Font("Candara",Font.BOLD,23));
		l3.setForeground(Color.black);
		l3.setBounds(300,230,200,30);
		l3.addActionListener(this);
		p.add(l3); 
		
		l4 = new JRadioButton(" Bkash ");
		l4.setFont(new Font("Candara",Font.BOLD,23));
		l4.setForeground(Color.black);
		l4.setBounds(300,280,200,30);
		l4.addActionListener(this);
		p.add(l4); 
		
		l5 = new JRadioButton(" Rocket ");
		l5.setFont(new Font("Candara",Font.BOLD,23));
		l5.setForeground(Color.black);
		l5.setBounds(300,330,200,30);
		l5.addActionListener(this);
		p.add(l5); 
		 
		
		b2 = new JButton("Back");
		b2.setBounds(50,700,120,30);
		b2.addActionListener(this);
		p.add(b2);
		
		this.add(p);
		
	}
	

public void actionPerformed(ActionEvent ae)
		{
		    if(ae.getSource()==l3)
			{
				Nagad f = new Nagad();
				this.setVisible(false);
				f.setVisible(true);
			}
			else if(ae.getSource()==l4)
			{
				Bkash f = new Bkash();
				this.setVisible(false);
				f.setVisible(true);
			}
			else if(ae.getSource()==l5)
			{
				Rocket f = new Rocket();
				this.setVisible(false);
				f.setVisible(true);
			}
			else if(ae.getSource() == b2){
				Menu f1 = new Menu();
				this.setVisible(false);
				f1.setVisible(true);
			}
		}


}
