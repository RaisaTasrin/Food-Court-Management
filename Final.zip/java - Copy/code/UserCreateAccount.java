package code;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import javax.swing.JPasswordField.*;

public class UserCreateAccount extends JFrame implements ActionListener {

    JLabel ImageL, TitleL, NameL, NumberL, LocationL, PassL, ConfirmL, l5;
    JTextField NameT, NumberT, LocationT;
	JPasswordField jp;
    JButton ConfirmB,BackB;
    JPanel MainP;
	ImageIcon img;

    Font font40 = new Font("Candara",Font.BOLD,40);
    Font font25 = new Font("Candara",Font.BOLD,25);
	Font font20 = new Font("Candara",Font.BOLD, 20);
	Font font18 = new Font("Candara",Font.BOLD, 18);
	Font font16 = new Font("Candara",Font.BOLD, 16); 

    public UserCreateAccount() {

        super(" Account Registration");
        this.setSize(1188, 850); 
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setLocationRelativeTo(null); 
        ImageIcon icon = new ImageIcon("AppIcon.jpg");
        this.setIconImage(icon.getImage());
     
        // MAIN PANEL...................
		MainP = new JPanel();
		MainP.setBounds(0,0,1188,850);
		MainP.setLayout(null);
		MainP.setBackground(Color.white);
		this.add(MainP);
		
		img = new ImageIcon("pic2.JPG");
		
	    ImageL = new JLabel(img);
		ImageL.setSize(1188,850);
		MainP.add(ImageL);

        TitleL = new JLabel("Create An Account"); // Corrected typo
        TitleL.setFont(font40);
        TitleL.setForeground(Color.black);
        TitleL.setBounds(230, 50, 350,50);
        ImageL.add(TitleL);

        NameL = new JLabel("Name:");
        NameL.setFont(font25);
        NameL.setForeground(Color.white);
        NameL.setBounds(50, 200, 170, 25);
        ImageL.add(NameL);

        NumberL = new JLabel("Number:");
        NumberL.setFont(font25);
        NumberL.setForeground(Color.white);
        NumberL.setBounds(50, 270, 170, 25);
        ImageL.add(NumberL);
		
		LocationL = new JLabel("Location:");
        LocationL.setFont(font25);
        LocationL.setForeground(Color.white);
        LocationL.setBounds(50, 340, 170, 25);
        ImageL.add(LocationL);
		
		
		PassL = new JLabel("Password:");
        PassL.setFont(font25);
        PassL.setForeground(Color.white);
        PassL.setBounds(50, 410, 170, 25);
        ImageL.add(PassL);

        NameT = new JTextField();
        NameT.setBounds(200, 200, 170, 35); 
        ImageL.add(NameT);
		
		NumberT = new JTextField();
        NumberT.setBounds(200, 270, 170, 35); 
        ImageL.add(NumberT);
		
		LocationT = new JTextField();
        LocationT.setBounds(200, 340, 170, 35); 
        ImageL.add(LocationT);

        jp = new JPasswordField();
        jp.setBounds(200, 410, 170, 35); 
		jp.setEchoChar('*');
        ImageL.add(jp);

		ConfirmB = new JButton("Confirm");
        ConfirmB.setFont(font18);
        ConfirmB.setForeground(Color.black);
        ConfirmB.setBounds(200, 500, 150, 40);
        ConfirmB.addActionListener(this);
        ImageL.add(ConfirmB);
		
		BackB = new JButton(" Back ");
		BackB.setBounds(50,750,120,30);
		BackB.setBackground(Color.GRAY);
		BackB.addActionListener(this);
		ImageL.add(BackB);
    }
    public void actionPerformed(ActionEvent ae) {
		 if (ae.getSource() == ConfirmB) {
			String user = NameT.getText();
			String num = NumberT.getText();
			String add = LocationT.getText();
			String pass = jp.getText();
            String unblock = "Unblock";
			 
			try{
				File file = new File("user.txt");
				FileWriter fw = new FileWriter(file,true);
                int id = 1;
				 
				fw.write(id+","+user+","+num+","+unblock+","+add+","+pass+"\n");
				fw.flush();
				fw.close();
                id++;
			 }
			catch(Exception e){
				 e.printStackTrace();
			 }
			 
             UserLogin f = new UserLogin();
				this.setVisible(false);
				f.setVisible(true);
        }
		
		
		else if (ae.getSource() == BackB) {
           UserLogin f = new UserLogin();
			this.setVisible(false);
            f.setVisible(true);
        }
	}
	
	
   
}

